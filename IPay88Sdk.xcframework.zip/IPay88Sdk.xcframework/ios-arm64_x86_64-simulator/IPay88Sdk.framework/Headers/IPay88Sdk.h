//
//  IPay88Sdk.h
//  IPay88Sdk
//
//  Created by kunTola on 24/3/22.
//  Tel.017847800
//  Email.kuntola883@gmail.com
//

#import <Foundation/Foundation.h>

//! Project version number for IPay88Sdk.
FOUNDATION_EXPORT double IPay88SdkVersionNumber;

//! Project version string for IPay88Sdk.
FOUNDATION_EXPORT const unsigned char IPay88SdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IPay88Sdk/PublicHeader.h>


